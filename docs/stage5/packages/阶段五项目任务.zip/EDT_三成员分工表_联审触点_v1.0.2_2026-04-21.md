# EDT 三成员分工表 + 联审触点
**版本**：v1.0.2  
**日期**：2026-04-21  
**用途**：明确 A / B / C 三成员职责边界、禁止改动范围、联审触点、交付物与各自完成标准。  
**来源**：由《EDT_施工顺序表_施工准备清单_三成员分工表_正式冻结版_v1.0.2》按用途拆分形成。  
**配套执行矩阵**：`EDT_阶段-负责人矩阵_v1.0_2026-04-21.md`（阶段主责、配合关系与串并行规则以该矩阵为准）  

---

# 一、总原则

## 原则 1：按模块边界分工，不按“感觉”分工
不能因为谁顺手就改谁。  
主责必须固定，避免多头改动。

## 原则 2：A 负责定义，C 负责落盘/校验，B 负责映射/消费
- **A**：契约、字段、Gate、状态机、兼容层
- **B**：sector / ticker / theme / A0/A1 映射
- **C**：replay / join / raw ingest / queue / perf / observability

## 原则 3：凡涉及三方触点，必须 Joint Review
未联审，不得合并。
联审时的发起责任和阶段串并行顺序，按配套执行矩阵执行。

## 原则 4：主定义真源必须唯一
尤其：
- **唯一主定义真源：`configs/sector_impact_mapping.yaml`**
- `registry/sectors_white_list.yaml` 仅允许作为引用 / 镜像文件
- 不得承载主定义

---

# 二、三成员分工表（正式版）

| 成员 | 主职责 | 只负责什么 | 明确不负责什么 | 交付物 |
|---|---|---|---|---|
| 成员 A | 契约 / Schema / Gate / 状态机 / 兼容层 | `contract_version`、dual-write、Gate、状态机、字段定义、枚举定义 | 不负责 replay writer/join 实现；不负责 ticker_pool；不负责 queue/perf | 契约升级稿、状态机定义、Gate 真源、字段 diff 方案 |
| 成员 B | sector / ticker / theme / A0/A1 映射一致性 | sector 白名单、ticker_pool、三段契约字段接入、theme_tags、A0/A1 绑定规则 | 不负责 replay 主键 writer/join；不负责 Gate；不负责执行器落盘 | sector registry、ticker_pool、三段契约接入、映射测试 |
| 成员 C | replay / join / 原始采样 / 队列 / 性能 / 观测 | raw ingest、replay 主键落盘、join、queue、provider perf、quarantine、日志与看板 | 不负责状态机枚举定义；不负责 contract 字段命名主责；不负责 sector/ticker 真源 | replay/join、raw ingest、provider adapter、性能优化、观测面板 |

---

# 三、A / B / C 联审触点（必须 Joint Review）

以下任何改动，必须三方共同签字：

- `contract_version`
- `trace_id / request_id / batch_id / event_trace_id / event_hash`
- `idempotency_key`
- `market_data_present/stale/fallback/default`
- `semantic_event_type / sector_candidates / ticker_candidates`
- `gate_input`
- `reject_reason_code`
- 状态机枚举
- provider 活跃路径定义

## 联审要求
- A / B / C 三方至少各 1 人签字
- 未联审，不得合并
- 若只是一方代码实现改动，但会影响其他两方解析，也必须联审

## 联审目的
防止：
- A 改了枚举不通知 B/C
- B 改了字段命名，C 的落盘脚本静默失败
- C 改了 join key，A/B 的 consumer 还按旧格式读

---

# 四、成员 A 详细职责

## A-1 契约版本升级
- 新增 / 维护 `contract_version`
- 实施 dual-write
- 明确 deprecated 字段

## A-2 唯一 Gate 真源
- 统一实现 `DecisionGate / OutputGate`
- 所有正式 `EXECUTE` 只认这一处

## A-3 状态机固化
固定并统一解释：
- `BLOCK`
- `NO_ACTION`
- `WATCH`
- `PENDING_CONFIRM`
- `EXECUTE`

固定优先级：
- `tradeable=false > final_action`

## A-4 replay 主键职责说明
**A 只定义字段，不实现 writer / join / validator。**

A 负责定义的 replay 主键字段包括：
- `event_trace_id`
- `request_id`
- `batch_id`
- `event_hash`
- `idempotency_key`

## A 交付完成标准
- [ ] 契约字段定义冻结
- [ ] 状态机冻结
- [ ] Gate 真源实现
- [ ] dual-write 方案闭合
- [ ] replay 主键字段定义完成，但不侵入 C 的 writer/join 实现

---

# 五、成员 B 详细职责

## B-1 sector 白名单唯一真源
- **唯一主定义真源：`configs/sector_impact_mapping.yaml`**
- `registry/sectors_white_list.yaml` 仅允许作为引用 / 镜像文件
- `registry/sectors_white_list.yaml` 不得承载主定义
- 必须由主 config 显式引用唯一真源路径

### B-1 执行约束
1. 所有 consumer、validator、测试夹具、验收脚本，均以 `configs/sector_impact_mapping.yaml` 为唯一判定基准。  
2. 若镜像文件与主定义真源不一致，以主定义真源为准，并视为配置一致性缺陷。  
3. 成员 B 负责主定义真源；成员 C 只能消费该真源，不得另行派生第二套 sector 判定口径。  

## B-2 三段契约落地
固定链路：
- `semantic_event_type`
- `sector_candidates`
- `ticker_candidates`

## B-3 ticker_pool 白名单
- ticker 只能来自 sector 对应池
- broad sector / sub-sector 双层一致性校验

## B-4 theme_tags / A0 Narrative Boost
- `theme_tags[]` 必须进入 A0 Narrative Boost
- 只能辅助加分，不得单独触发 `EXECUTE`

## B-5 A1 target_tracking
- 必须绑定目标标的 / 代理资产
- 不得泛市场高分

## B 交付完成标准
- [ ] `sectors[]` 非白名单 = 0
- [ ] ticker 错配率显著下降
- [ ] `theme_tags` 不再是幽灵字段
- [ ] A1 与真实目标资产绑定

---

# 六、成员 C 详细职责

## C-1 replay 主键与 join 完整性
**C 负责实现 writer / join / validator。**

强制落盘：
- `event_trace_id`
- `request_id`
- `batch_id`
- `event_hash`

## C-2 原始采样落盘
新增：
- `raw_news_ingest.jsonl`

## C-3 队列调度升级
- FIFO → 新鲜度优先
- 保留：
  - `ingest_seq`
  - `process_seq`

## C-4 并发抓价 + 幂等
- adapter
- batch
- cache
- failover
- `idempotency_key`

## C-5 Quarantine Activity Monitor
建立隔离流活跃度监测。

### 触发报警条件
仅当以下条件同时满足时触发：
1. `gate_enabled = true`
2. `ingest_count_1h > 0`
3. `rejected_events_count_1h = 0`
4. `quarantine_replay_count_1h = 0`

触发报警：
- `QUARANTINE_SILENT_ALERT`

### 不触发场景
- 非交易时段无输入
- 夜盘 / 低流量时段 `ingest_count_1h = 0`
- Gate 尚未开启
- 维护 / 回放 / test 模式且被显式豁免

## C 交付完成标准
- [ ] replay 主键完整率 = 100%
- [ ] orphan replay = 0
- [ ] 原始采样可回溯
- [ ] 优先级队列不破坏 ingest 真源顺序
- [ ] 重试不重复写 replay / 不重复执行
- [ ] 隔离流活跃度监测已上线

---

# 七、协作禁令

## 7.1 未经同步不得私改
- A 不得私改 ticker_pool
- B 不得私改 replay 主键 writer / join
- C 不得私改状态机枚举
- C 不得私改 contract 字段命名主责
- B/C 不得私自改变 sector 主定义真源

## 7.2 以下文件只允许串行改动
- `configs/edt-modules-config.yaml`
- `configs/sector_impact_mapping.yaml`
- `registry/ticker_pool.yaml`
- `schemas/*.json`
- `contracts/*.yaml`

## 7.3 串行改动规则
1. 先出字段 diff 方案，再改代码  
2. 先改真源，再改 consumer  
3. 未审过 schema diff，不得提交 producer 改动  

---

# 八、三成员各自必须通过的门槛

## A 必须满足
- Gate 真源实现
- 状态机冻结
- dual-write 闭合
- `tradeable=false > final_action` 代码与文档一致

## B 必须满足
- sector 真源唯一
- ticker_pool 白名单闭环
- `theme_tags` 不再是幽灵字段
- A1 不再泛市场高分

## C 必须满足
- replay 主键完整率 = 100%
- orphan replay = 0
- raw ingest 落盘
- queue 顺序语义正确
- 幂等写入正确
- quarantine monitor 上线

---

# 九、一句话执行口令

**A 负责定义，B 负责映射，C 负责落盘与性能；凡涉及 contract、主键、provider、状态机、Gate 输入与 provenance 字段，必须三方 Joint Review，未联审不得合并。**
