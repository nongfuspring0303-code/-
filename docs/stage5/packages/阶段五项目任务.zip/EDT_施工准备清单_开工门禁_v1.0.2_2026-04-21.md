# EDT 施工准备清单 + 开工门禁
**版本**：v1.0.2  
**日期**：2026-04-21  
**用途**：专门服务开工前检查，明确哪些东西没准备好就不能开工。  
**来源**：由《EDT_施工顺序表_施工准备清单_三成员分工表_正式冻结版_v1.0.2》按用途拆分形成。  
**配套执行矩阵**：`EDT_阶段-负责人矩阵_v1.0_2026-04-21.md`（用于开工前确认每阶段主责/配合与串并行规则）  

---

# 一、开工前总目标

本轮施工准备的目标不是“先写代码”，而是把以下前提全部锁死：

1. **封住错误执行路径**
   - 无 `opportunity_update` 时绝不允许 `EXECUTE`
   - fallback 不得伪装为正式 sector / ticker
   - `tradeable=false` 时执行器必须拒绝消费

2. **恢复链路确定性**
   - `semantic_event_type -> sector_candidates -> ticker_candidates` 三段契约显式化
   - `sectors[]` 白名单化
   - replay 与 event trace 可稳定回指

3. **在不破坏现网兼容性的前提下再做性能优化**
   - dual-write
   - additive change
   - feature flag 灰度
   - 顺序语义 + 幂等语义

---

# 二、开工前必须冻结的内容

- [ ] 普通基线快照
- [ ] 压测基线快照
- [ ] 黄金样本
- [ ] 三成员职责边界
- [ ] schema / config / registry 真源
- [ ] feature flags
- [ ] rollback 条件
- [ ] rollback sanitization 脚本
- [ ] rejected / quarantine 流
- [ ] 联审触点清单

---

# 三、基线快照（必须先冻结）

## 3.1 普通基线
开工前至少冻结以下指标：
- `missing_opportunity_but_execute_rate`
- `fallback_leak_rate`
- `financial_rate`
- `sectors_non_whitelist_rate`
- `replay_primary_key_completeness`
- `trace_join_success_rate`
- `event_without_sector_rate`
- `p95_decision_latency`
- `same_trace_ai_duplicate_call_rate`

## 3.2 压测基线（Stress-Tested Baseline）
除了普通基线，还必须包含一次高并发 / 突发新闻行情下的压测快照，至少输出：
- `queue_backlog_peak`
- `raw_ingest_to_event_update_p95`
- `raw_ingest_to_replay_p95`
- `provider_timeout_rate`
- `provider_rate_limited_rate`
- `same_trace_ai_duplicate_call_rate`
- `market_data_default_used_rate`
- `execution_blocked_by_gate_rate`

## 3.3 基线输出文件
- `docs/baseline/edt_fix_baseline_2026-04-21.md`
- `artifacts/baseline/metrics_snapshot_2026-04-21.json`
- `artifacts/baseline/stress_metrics_snapshot_2026-04-21.json`

## 3.4 门禁
- 没有基线快照，**不得开工**
- 没有压测基线，**不得开工**
- 没有冻结样本，**不得改测试**

---

# 四、黄金样本（必须先准备）

至少准备以下样本集，每类不少于 5 条：

1. AI / 算力 / 半导体新闻  
2. 宏观 / 利率 / CPI / 债券新闻  
3. 商品 / 原油 / 黄金 / 天然气新闻  
4. 地缘政治 / 战争 / 制裁 / 谈判新闻  
5. 天气 / 例行会晤 / 中性观察类新闻  
6. 过去出现过 `金融(LONG)+JPM(None)` 的错误样本  
7. 过去出现“无 opportunity 仍 EXECUTE”的错误样本  
8. replay orphan / 主键为空 / 无法 join 的错误样本  

## 样本输出路径
- `tests/fixtures/edt_goldens/`
- `tests/fixtures/replay_join_cases/`

## 门禁
- 没有黄金样本，**不得声称修复有效**
- 没有错误复现样本，**不得删旧逻辑**

---

# 五、Feature Flags / 回滚方案（必须先建）

## 5.1 最少 flags
- `enable_contract_v22_dual_write`
- `enable_output_gate_v2`
- `enable_sector_whitelist_v2`
- `enable_theme_tags_routing_v2`
- `enable_ticker_pool_v2`
- `enable_replay_join_validation_v2`
- `enable_priority_queue_v2`
- `enable_parallel_price_fetch_v2`

## 5.2 回滚要求
每个 flag 必须明确：
- 默认值
- 打开范围
- 打开条件
- 回滚条件
- 回滚负责人

## 5.3 Rollback Sanitization（必须有）
每个回滚开关，必须配套一份：
- 脏数据重置脚本
- 或清洗 / 迁移脚本
- 或兼容降级脚本

### 至少覆盖
- v2.2 新字段
- replay 主键新格式
- Gate 新 reject reason code
- provenance 字段
- scorecard / quarantine / provider health 记录

## 5.4 门禁
- 没有 feature flag，**不得上线新 gate**
- 没有 rollback 条件，**不得切换默认路径**
- 没有 rollback sanitization，**不得灰度**

---

# 六、Rejected / Quarantine 流（必须先建）

所有被新 gate 拦下的事件，必须有去向，不能静默消失。

## 6.1 必须落盘的流
- `rejected_events.jsonl`
- `quarantine_replay.jsonl`

## 6.2 最少字段
- `trace_id`
- `event_trace_id`
- `stage`
- `reject_reason_code`
- `reject_reason_text`
- `contract_version`
- `ingest_ts`
- `decision_ts`

## 6.3 Quarantine Activity Monitor
必须建立：
- `quarantine_activity_monitor`

### 触发报警条件
仅当以下条件 **同时满足** 时，才触发：
1. `gate_enabled = true`
2. `ingest_count_1h > 0`
3. `rejected_events_count_1h = 0`
4. `quarantine_replay_count_1h = 0`

则触发报警：
- `QUARANTINE_SILENT_ALERT`

### 不触发场景
- 非交易时段无输入
- 夜盘 / 低流量时段 `ingest_count_1h = 0`
- Gate 尚未开启
- 维护 / 回放 / test 模式且被显式豁免

## 6.4 门禁
- 没有 quarantine 流，**不得扩大 gate 拦截面**
- 没有 reject reason code，**不得统计误杀率**

---

# 七、文件 / 真源 / 联审前置条件

## 7.1 schema / config / registry 真源
以下真源路径必须先锁定：
- `configs/edt-modules-config.yaml`
- `configs/sector_impact_mapping.yaml`
- `registry/ticker_pool.yaml`
- `schemas/*.json`（如有）
- `contracts/*.yaml`（如有）

### 特别说明
- **唯一主定义真源：`configs/sector_impact_mapping.yaml`**
- `registry/sectors_white_list.yaml` 仅允许作为引用 / 镜像文件
- 不得承载主定义

## 7.2 联审触点清单（必须先发布）
凡涉及以下触点，改动必须 Joint Review：
- `contract_version`
- `trace_id / request_id / batch_id / event_trace_id / event_hash`
- `idempotency_key`
- `market_data_present/stale/fallback/default`
- `semantic_event_type / sector_candidates / ticker_candidates`
- `gate_input`
- `reject_reason_code`
- 状态机枚举
- provider 活跃路径定义

---

# 八、Go / No-Go 门禁

## 8.1 Go 条件（全部满足才允许开工）
- [ ] 基线已冻结
- [ ] 压测基线已冻结
- [ ] 黄金样本已准备
- [ ] 三成员边界已确认
- [ ] 阶段-负责人矩阵已发布并完成 A/B/C 确认
- [ ] flags 已建立
- [ ] rollback 条件已写明
- [ ] rollback sanitization 脚本已存在
- [ ] quarantine 流已建
- [ ] schema 真源已锁定
- [ ] 联审触点清单已发布

## 8.2 No-Go 一票否决项
- [ ] 没有基线快照
- [ ] 没有压测基线
- [ ] 没有 rollback 方案
- [ ] 没有 rollback sanitization
- [ ] 没有 quarantine 流
- [ ] 没有黄金错误样本
- [ ] 没有阶段-负责人矩阵或未完成 A/B/C 确认
- [ ] 三成员并行改 schema
- [ ] 没有 Joint Review 就改触点字段
- [ ] 没有 blocker test 就准备合并

---

# 九、Definition of Ready（DoR）

以下全部满足，才允许进入正式编码施工：

- [ ] v1.2 主稿已冻结
- [ ] 本施工准备文件已冻结
- [ ] 基线 + 压测基线已冻结
- [ ] 黄金样本已准备
- [ ] 分工边界已明确
- [ ] Joint Review 触点已公布
- [ ] flags 已建立
- [ ] rollback + sanitization 已建立
- [ ] quarantine 流准备完毕
- [ ] schema/config 真源已锁定

---

# 十、一句话执行口令

**未完成基线（含压测基线）、样本、flags、rollback、sanitization、quarantine 流、真源锁定与联审触点清单之前，不得正式开工。**
