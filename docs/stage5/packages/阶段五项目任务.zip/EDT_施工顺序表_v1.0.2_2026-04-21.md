# EDT 施工顺序表
**版本**：v1.0.2  
**日期**：2026-04-21  
**用途**：给执行同伴直接照着做，明确先做什么、再做什么、最后做什么，以及每一阶段做到什么才算完成。  
**来源**：由《EDT_施工顺序表_施工准备清单_三成员分工表_正式冻结版_v1.0.2》按用途拆分形成。  
**配套执行矩阵**：`EDT_阶段-负责人矩阵_v1.0_2026-04-21.md`（阶段主责/配合/串并行以该矩阵为准）  

---

# 一、总原则

这次施工顺序不能搞反：

- 不是先把整套日志全做完，再修业务
- 不是先不管日志，直接大改业务逻辑
- 更不是先做性能优化

## 正确顺序
### 阶段 0
**施工准备：冻结基线、样本、真源、flags、rollback**

### 阶段 1
**先补最小可用证据日志**

### 阶段 2
**同步修 P0 blocker**

### 阶段 3
**修主链路输出病灶**

### 阶段 4
**修 Provider / 抓价 / 性能层**

### 阶段 5
**补完整日志、评分体系、看板**

一句话：

> **先补关键证据，再切最危险错误，再修主要输出，再提速，最后做全套观测。**

---

# 二、阶段 0：施工准备（不大改主链路）

## 目标
冻结基线、样本、分工、真源、flags、rollback。

## 必做事项
1. 冻结当前基线快照  
2. 冻结黄金样本  
3. 明确三成员分工与文件边界  
4. 建立 feature flags / rollback 方案  
5. 建 rejected / quarantine 流  
6. 锁定 schema / config / registry 真源  
7. 输出一次普通基线 + 一次压测基线  

## 本阶段新增要求
- 增加 **Stress-Tested Baseline**
- 增加 **Joint Review 触点列表**
- 增加 **Rollback Sanitization 清单**

## 完成标志
- [ ] 普通基线已冻结
- [ ] 压测基线已冻结
- [ ] 黄金样本已准备
- [ ] 分工边界已冻结
- [ ] flags 已建立
- [ ] rollback + sanitization 已建立
- [ ] quarantine 流已存在
- [ ] schema/config 真源已锁定

---

# 三、阶段 1：先补最小可用证据日志

## 目标
让系统从“难解释”变成“能定位主责”。

## 只做 4 类关键日志（对应 5 个落盘文件）
1. `raw_news_ingest.jsonl`
2. `market_data_provenance.jsonl`
3. `decision_gate.jsonl`
4. Replay / Execution 分离日志：
   - `replay_write.jsonl`
   - `execution_emit.jsonl`

## 本阶段禁止做的事
- 不做完整 stage log
- 不做豪华看板
- 不做全套评分体系
- 不先改 provider 大架构

## 完成标志
- [ ] **4 类关键日志（5 个落盘文件）** 已落盘
- [ ] trace_id 可贯穿串联
- [ ] 能直接回答：
  - 系统抓到了什么
  - 市场数据是真是假
  - 为什么放行 / 阻断
  - replay 和 execution 是否漂移

---

# 四、阶段 2：同步修 P0 blocker（与阶段 1 并行）

## 目标
切断当前最危险、会持续制造假结论的路径。

## 必修项
1. 切掉 A1 默认值伪装  
2. 给 MarketValidator 加 provenance 防线  
3. 封执行红线：
   - `missing opportunity -> no EXECUTE`
   - `market_data_stale -> no EXECUTE`
   - `market_data_default_used -> no EXECUTE`
   - `market_data_fallback_used -> no EXECUTE`

## 完成标志
- [ ] A1 不再吃默认伪造输入
- [ ] MarketValidator 可识别 stale / fallback / default
- [ ] 红线已进入 Gate
- [ ] blocker 测试通过

---

# 五、阶段 3：修主链路输出病灶

## 目标
把当前“功能性致残”的主链路拉回可信状态。

## 修复顺序
1. replay 主键 / join 完整性  
2. 无 opportunity 仍 EXECUTE 全链路堵死  
3. sector 白名单  
4. ticker_pool 白名单  
5. 删除金融 / JPM 伪兜底  
6. 清 placeholder / template collapse  

## 完成标志
- [ ] replay 主键完整率 = 100%
- [ ] orphan replay = 0
- [ ] 无 opportunity 不再 EXECUTE
- [ ] `sectors[]` 非白名单占比 = 0
- [ ] ticker 错配率显著下降
- [ ] fallback 不再伪装成金融 / JPM
- [ ] placeholder 泄漏率 ≤ 1%

---

# 六、阶段 4：修 Provider / 抓价 / 性能层

## 目标
把“能工作但慢、Provider 脆弱”的链路升级成可用链路。

## 修复顺序
1. 抽统一 `MarketDataAdapter`
2. 把单票同步抓价升级为 batch + cache
3. 补 active / fallback / deprecated provider 配置治理
4. 补 queue 顺序语义与幂等语义
5. 验证压测表现是否改善

## 本阶段新增强制测试
第 7-9 项从“建议”升级为“本阶段必过”：
7. `dual_write_backward_compat_test`
8. `priority_queue_order_semantics_test`
9. `idempotent_replay_write_test`

## 完成标志
- [ ] adapter 已接入
- [ ] 单票同步主路径被移除
- [ ] batch 抓价可用
- [ ] provider failover 可用
- [ ] config-runtime alignment 通过
- [ ] 压测基线较旧基线有明确改善
- [ ] 第 7-9 项附加门禁测试全部通过

---

# 七、阶段 5：补完整日志 + 评分体系 + 看板

## 目标
把系统从“可修”升级成“可运营、可评分、可复盘”。

## 继续补什么
1. `pipeline_stage.jsonl`
2. `rejected_events.jsonl`
3. `quarantine_replay.jsonl`
4. `provider_health_hourly.json`
5. `trace_scorecard.jsonl`
6. `system_health_daily.json`
7. `system_log_evaluator.py`
8. 看板 / 日报

## 完成标志
- [ ] stage log 全覆盖
- [ ] quarantine / rejected 可回溯
- [ ] 隔离流活跃度监测已上线
- [ ] provider 健康可统计
- [ ] 每日评分自动产出
- [ ] 系统有统一健康总评

---

# 八、绝对不要采用的错误顺序

## 错误顺序 A
先把完整日志全做完，再修业务

### 为什么错
- blocker 继续活着
- 系统继续制造假结论
- 只会更完整地记录错误

## 错误顺序 B
完全不补日志，直接修业务

### 为什么错
- 修完无法证明
- 无法归因
- 无法比较提升
- 很容易再次漏掉 hidden fallback

## 错误顺序 C
先做性能优化

### 为什么错
- 只会更快地产生错结果
- 不会先解决错误执行和假验证

---

# 九、发群版执行口令

**先冻结基线（含压测基线）和真源，再上兼容层和唯一 Gate；先补最小证据日志，再切 A1 假验证和执行红线；再修 replay/join、sector/ticker、金融伪兜底；再做 provider/perf；最后补完整日志、评分、看板。凡涉及三方触点，必须 Joint Review；凡涉及回滚，必须带 sanitization 脚本；未满足数字化 DoD，不得宣称完成。**
