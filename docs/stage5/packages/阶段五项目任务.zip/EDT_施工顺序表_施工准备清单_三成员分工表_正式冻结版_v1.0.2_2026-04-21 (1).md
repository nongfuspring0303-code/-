# EDT 施工顺序表 + 施工准备清单 + 三成员分工表（正式冻结版）
**版本**：v1.0.2  
**日期**：2026-04-21  
**用途**：将现有《施工顺序》《施工准备清单 + 三成员分工表 + 开工门禁》《日志方案》与审查新增意见统一收敛为一份可直接发群、可直接执行、可直接冻结的正式施工底稿。  
**适用范围**：EDT 交易系统全链路逻辑修复、日志增强、输出治理、Provider/性能优化。  
**配套执行矩阵**：`EDT_阶段-负责人矩阵_v1.0_2026-04-21.md`（阶段主责/配合/串并行规则以该矩阵为准）  

---

# 一、审查结论总览（先给团队统一口径）

## 1.1 总体结论
**总体认可。**  
这套施工思路可以作为开工底稿，主顺序正确，优先级也基本合理。

但按正式审查口径，v1.0.1 仍需补 1 个 MAJOR + 2 个 MINOR 才适合正式冻结；本 v1.0.2 已完成这 3 项收口：（1）冻结 sector 白名单唯一真源；（2）补强 `QUARANTINE_SILENT_ALERT` 触发前提，避免低流量误报；（3）统一“4 类关键日志（5 个落盘文件）”口径。

---

## 1.2 v1.0.2 冻结前已完成的关键收口

### MAJOR：sector 白名单真源单点冻结
#### 最终落地规则
- **唯一主定义真源：`configs/sector_impact_mapping.yaml`**
- `registry/sectors_white_list.yaml` **仅允许作为引用/镜像文件**
- `registry/sectors_white_list.yaml` **不得承载主定义**
- 所有 consumer、validator、测试夹具、验收脚本，均以 `configs/sector_impact_mapping.yaml` 为唯一判定基准
- `configs/edt-modules-config.yaml` 必须显式指向该唯一真源路径

### MINOR：`QUARANTINE_SILENT_ALERT` 触发前提补强
#### 最终触发条件
仅当以下条件 **同时满足** 时，才触发：
1. `gate_enabled = true`
2. `ingest_count_1h > 0`
3. `rejected_events_count_1h = 0`
4. `quarantine_replay_count_1h = 0`

则触发报警：
- `QUARANTINE_SILENT_ALERT`

### MINOR：阶段 1 口径统一
#### 最终写法
阶段 1 统一表述为：

> **4 类关键日志（5 个落盘文件）**

其中：
- 第 1 类：`raw_news_ingest.jsonl`
- 第 2 类：`market_data_provenance.jsonl`
- 第 3 类：`decision_gate.jsonl`
- 第 4 类：Replay / Execution 分离日志：
  - `replay_write.jsonl`
  - `execution_emit.jsonl`


# 二、额外采纳的 5 条优化建议（全部并入正式执行版）

---

## 2.1 协同边界补强：接口变更联审制（Joint PR Review）
### 新增位置
第六章《文件边界与修改规则》

### 新增硬规则
凡涉及 A / B / C 三方逻辑交汇的“触点”，改动必须走 **Joint Review（联合签字）**。

### 触点示例
- `contract_version`
- 状态机枚举
- `gate_input` 字段定义
- `event_trace_id / request_id / batch_id / event_hash`
- `idempotency_key` 格式
- `market_data_present/stale/fallback/default` 等 provenance 字段
- `semantic_event_type / sector_candidates / ticker_candidates`
- `DecisionGate` 的 reject reason code

### 联审要求
- A/B/C 三方至少各 1 人签字
- 未联审，不得合并
- 若只是一方代码实现改动，但会影响其他两方解析，也必须联审

### 目的
防止：
- A 改了枚举不通知 B/C
- B 改了字段命名，C 的落盘脚本静默失败
- C 改了 join key，A/B 的 consumer 还按旧格式读

---

## 2.2 回滚逻辑完整性：Rollback Sanitization（回滚数据清洗脚本）
### 新增位置
第十章《灰度、回滚与观测要求》

### 新增硬规则
每个回滚开关，必须配套一份：
- **脏数据重置脚本**
- 或 **清洗/迁移脚本**
- 或 **兼容降级脚本**

### 必须覆盖的对象
- v2.2 新字段
- replay 主键新格式
- Gate 新 reject reason code
- 新增 provenance 字段
- 新增 scorecard / quarantine / provider health 记录

### 目的
因为 flag 回滚只能改代码路径，**不能自动清除已经写入的数据碎片**。  
如果没有清洗脚本：
- 旧 consumer 读到 v2.2 数据会崩
- 回滚后 replay / execution / logs 可能形成逻辑碎片

---

## 2.3 防空转门禁：Quarantine Activity Monitor（隔离流活跃度监测）
### 新增位置
第 3.4 节《Rejected / Quarantine 流》
以及 成员 C 职责

### 新增硬规则
必须建立：
- `quarantine_activity_monitor`

### 触发报警条件
仅当以下条件 **同时满足** 时，才触发：

1. `gate_enabled = true`
2. `ingest_count_1h > 0`
3. `rejected_events_count_1h = 0`
4. `quarantine_replay_count_1h = 0`

则触发报警：
- `QUARANTINE_SILENT_ALERT`

### 不触发场景
以下场景不得触发该报警：
- 非交易时段无输入
- 夜盘 / 低流量时段 `ingest_count_1h = 0`
- Gate 尚未开启
- 系统处于维护 / 回放 / test 模式且被显式豁免

### 目的
隔离流为 0 不一定代表系统完美，往往更可能代表：
- Gate 被旁路
- 拒绝被静默吞掉
- reject reason 未落盘
- 异常被 try/except 吃掉

---

## 2.4 基线真实性补强：Stress-Tested Baseline（压测基线）
### 新增位置
第 3.1 节《基线快照》

### 新增硬规则
基线不仅要记录日常值，还必须包含：
- **一次高并发 / 突发新闻行情下的压测快照**

### 至少输出以下压测基线指标
- `queue_backlog_peak`
- `raw_ingest_to_event_update_p95`
- `raw_ingest_to_replay_p95`
- `provider_timeout_rate`
- `provider_rate_limited_rate`
- `same_trace_ai_duplicate_call_rate`
- `market_data_default_used_rate`
- `execution_blocked_by_gate_rate`

### 目的
因为你们已经暴露过极端负载下的长时延问题。  
如果只看低负载基线，后续无法证明：
- Provider 优化是否真的解决堆积
- 队列优化是否真的解决 backlog

---

## 2.5 完成标准补强：Shadow Code Purge Gate（影子代码清理门禁）
### 新增位置
第十三章《DoD 完成标准》

### 新增硬规则
正式收口前必须执行：
- 全局 `grep`
- 清理所有非日志体系的 `print`
- 清理临时调试输出
- 清理临时 patch / TODO-ONLY hack
- 清理仅为排查用的临时变量和分支

### 必须清理的典型项
- `print(...)`
- `pprint(...)`
- 临时 `logger.info("debug only ...")`
- 临时 `time.sleep(...)`
- 临时 bypass 逻辑
- 临时 hardcode fallback

### 目的
避免：
- 实盘 IO 性能被调试输出污染
- 影子逻辑继续潜伏
- 生产环境行为与设计文档不一致

---

# 三、最终施工总顺序（正式冻结版）

> 这是最终执行顺序。  
> 先后顺序不允许颠倒。  
> 未满足上一阶段完成标志，不得进入下一阶段。

---

## 阶段 0：施工准备（不大改主链路）
### 目标
冻结基线、样本、分工、真源、flags、rollback。

### 必做事项
1. 冻结当前基线快照  
2. 冻结黄金样本  
3. 明确三成员分工与文件边界  
4. 建立 feature flags / rollback 方案  
5. 建 rejected / quarantine 流  
6. 锁定 schema / config / registry 真源  
7. 输出一次普通基线 + 一次压测基线

### 本阶段新增要求
- 增加 **Stress-Tested Baseline**
- 增加 **Joint Review 触点列表**
- 增加 **Rollback Sanitization 清单**

### 完成标志
- [ ] 普通基线已冻结
- [ ] 压测基线已冻结
- [ ] 黄金样本已准备
- [ ] 分工边界已冻结
- [ ] flags 已建立
- [ ] rollback + sanitization 已建立
- [ ] quarantine 流已存在
- [ ] schema/config 真源已锁定

---

## 阶段 1：先补最小可用证据日志
### 目标
让系统从“难解释”变成“能定位主责”。

### 只做 4 类关键日志（对应 5 个落盘文件）
1. `raw_news_ingest.jsonl`
2. `market_data_provenance.jsonl`
3. `decision_gate.jsonl`
4. `replay_write.jsonl` + `execution_emit.jsonl`

### 本阶段禁止做的事
- 不做完整 stage log
- 不做豪华看板
- 不做全套评分体系
- 不先改 provider 大架构

### 完成标志
- [ ] **4 类关键日志（5 个落盘文件）** 已落盘
- [ ] trace_id 可贯穿串联
- [ ] 能直接回答：
  - 系统抓到了什么
  - 市场数据是真是假
  - 为什么放行/阻断
  - replay 和 execution 是否漂移

---

## 阶段 2：同步修 P0 blocker（与阶段 1 并行）
### 目标
切断当前最危险、会持续制造假结论的路径。

### 必修项
1. 切掉 A1 默认值伪装  
2. 给 MarketValidator 加 provenance 防线  
3. 封执行红线：
   - `missing opportunity -> no EXECUTE`
   - `market_data_stale -> no EXECUTE`
   - `market_data_default_used -> no EXECUTE`
   - `market_data_fallback_used -> no EXECUTE`

### 完成标志
- [ ] A1 不再吃默认伪造输入
- [ ] MarketValidator 可识别 stale/fallback/default
- [ ] 红线已进入 Gate
- [ ] blocker 测试通过

---

## 阶段 3：修主链路输出病灶
### 目标
把当前“功能性致残”的主链路拉回可信状态。

### 修复顺序
1. replay 主键 / join 完整性  
2. 无 opportunity 仍 EXECUTE 全链路堵死  
3. sector 白名单  
4. ticker_pool 白名单  
5. 删除金融/JPM 伪兜底  
6. 清 placeholder / template collapse  

### 完成标志
- [ ] replay 主键完整率 = 100%
- [ ] orphan replay = 0
- [ ] 无 opportunity 不再 EXECUTE
- [ ] `sectors[]` 非白名单占比 = 0
- [ ] ticker 错配率显著下降
- [ ] fallback 不再伪装成金融/JPM
- [ ] placeholder 泄漏率 ≤ 1%

---

## 阶段 4：修 Provider / 抓价 / 性能层
### 目标
把“能工作但慢、Provider 脆弱”的链路升级成可用链路。

### 修复顺序
1. 抽统一 `MarketDataAdapter`
2. 把单票同步抓价升级为 batch + cache
3. 补 active/fallback/deprecated provider 配置治理
4. 补 queue 顺序语义与幂等语义
5. 验证压测表现是否改善

### 本阶段新增强制测试
第 7-9 项从“建议”升级为“本阶段必过”：
7. `dual_write_backward_compat_test`
8. `priority_queue_order_semantics_test`
9. `idempotent_replay_write_test`

### 完成标志
- [ ] adapter 已接入
- [ ] 单票同步主路径被移除
- [ ] batch 抓价可用
- [ ] provider failover 可用
- [ ] config-runtime alignment 通过
- [ ] 压测基线较旧基线有明确改善
- [ ] 第 7-9 项附加门禁测试全部通过

---

## 阶段 5：补完整日志 + 评分体系 + 看板
### 目标
把系统从“可修”升级成“可运营、可评分、可复盘”。

### 继续补什么
1. `pipeline_stage.jsonl`
2. `rejected_events.jsonl`
3. `quarantine_replay.jsonl`
4. `provider_health_hourly.json`
5. `trace_scorecard.jsonl`
6. `system_health_daily.json`
7. `system_log_evaluator.py`
8. 看板 / 日报

### 完成标志
- [ ] stage log 全覆盖
- [ ] quarantine / rejected 可回溯
- [ ] 隔离流活跃度监测已上线
- [ ] provider 健康可统计
- [ ] 每日评分自动产出
- [ ] 系统有统一健康总评

---

# 四、施工准备清单（修订版）

## 4.1 开工前必须冻结的内容
- [ ] 普通基线快照
- [ ] 压测基线快照
- [ ] 黄金样本
- [ ] 三成员职责边界
- [ ] schema / config / registry 真源
- [ ] feature flags
- [ ] rollback 条件
- [ ] rollback sanitization 脚本
- [ ] rejected / quarantine 流
- [ ] 联审触点清单

---

## 4.2 开工前必须建立的文件 / 脚本
- [ ] `docs/baseline/edt_fix_baseline_2026-04-21.md`
- [ ] `artifacts/baseline/metrics_snapshot_2026-04-21.json`
- [ ] `artifacts/baseline/stress_metrics_snapshot_2026-04-21.json`
- [ ] `tests/fixtures/edt_goldens/`
- [ ] `tests/fixtures/replay_join_cases/`
- [ ] `scripts/rollback_sanitize_v22.py`（或同类脚本）
- [ ] `logs/rejected_events.jsonl`
- [ ] `logs/quarantine_replay.jsonl`

---

## 4.3 开工前必须明确的门禁
### Go 条件（全部满足）
- [ ] 基线已冻结
- [ ] 压测基线已冻结
- [ ] 黄金样本已准备
- [ ] 三成员边界已确认
- [ ] 阶段-负责人矩阵已发布并完成 A/B/C 确认
- [ ] flags 已建立
- [ ] rollback 条件已写明
- [ ] rollback sanitization 脚本已存在
- [ ] quarantine 流已建
- [ ] schema 真源已锁定
- [ ] 联审触点清单已发布

### No-Go 一票否决项
- [ ] 没有基线快照
- [ ] 没有压测基线
- [ ] 没有 rollback 方案
- [ ] 没有 rollback sanitization
- [ ] 没有 quarantine 流
- [ ] 没有黄金错误样本
- [ ] 没有阶段-负责人矩阵或未完成 A/B/C 确认
- [ ] 三成员并行改 schema
- [ ] 没有 Joint Review 就改触点字段
- [ ] 没有 blocker test 就准备合并

---

# 五、三成员分工表（修订版）

> 原则：按模块边界分工。  
> 原则：凡涉及三方触点，必须 Joint Review。  
> 原则：A 负责定义，C 负责落盘/校验，B 负责映射/消费，不交叉抢主责。

| 成员 | 主职责 | 只负责什么 | 明确不负责什么 | 交付物 |
|---|---|---|---|---|
| 成员 A | 契约 / Schema / Gate / 状态机 / 兼容层 | `contract_version`、dual-write、Gate、状态机、字段定义、枚举定义 | 不负责 replay writer/join 实现；不负责 ticker_pool；不负责 queue/perf | 契约升级稿、状态机定义、Gate 真源、字段 diff 方案 |
| 成员 B | sector / ticker / theme / A0/A1 映射一致性 | sector 白名单、ticker_pool、三段契约字段接入、theme_tags、A0/A1 绑定规则 | 不负责 replay 主键 writer/join；不负责 Gate；不负责执行器落盘 | sector registry、ticker_pool、三段契约接入、映射测试 |
| 成员 C | replay / join / 原始采样 / 队列 / 性能 / 观测 | raw ingest、replay 主键落盘、join、queue、provider perf、quarantine、日志与看板 | 不负责状态机枚举定义；不负责 contract 字段命名主责；不负责 sector/ticker 真源 | replay/join、raw ingest、provider adapter、性能优化、观测面板 |

---

## 5.1 A / B / C 联审触点（必须 Joint Review）
以下任何改动，必须三方共同签字：

- `contract_version`
- `trace_id / request_id / batch_id / event_trace_id / event_hash`
- `idempotency_key`
- `market_data_present/stale/fallback/default`
- `semantic_event_type / sector_candidates / ticker_candidates`
- `gate_input` 字段
- `reject_reason_code`
- 状态机枚举
- provider 活跃路径定义

---

## 5.2 成员 A 详细职责（修订）
### A-1 契约版本升级
- 新增/维护 `contract_version`
- 实施 dual-write
- 明确 deprecated 字段

### A-2 唯一 Gate 真源
- 统一实现 `DecisionGate / OutputGate`
- 所有正式 `EXECUTE` 只认这一处

### A-3 状态机固化
- `BLOCK / NO_ACTION / WATCH / PENDING_CONFIRM / EXECUTE`
- 固定优先级：`tradeable=false > final_action`

### A-4 replay 主键职责说明（修订）
- **A 只定义字段，不实现 writer / join / validator**
- 字段包括：
  - `event_trace_id`
  - `request_id`
  - `batch_id`
  - `event_hash`
  - `idempotency_key`

### A 交付完成标准
- [ ] 契约字段定义冻结
- [ ] 状态机冻结
- [ ] Gate 真源实现
- [ ] dual-write 方案闭合
- [ ] replay 主键字段定义完成，但不侵入 C 的 writer/join 实现

---

## 5.3 成员 B 详细职责（修订）
### B-1 sector 白名单唯一真源
- **唯一主定义真源：`configs/sector_impact_mapping.yaml`**
- `registry/sectors_white_list.yaml` 仅允许作为引用/镜像文件
- `registry/sectors_white_list.yaml` 不得承载主定义
- 必须由主 config 显式引用唯一真源路径

#### B-1 执行约束
1. 所有 consumer、validator、测试夹具、验收脚本，均以 `configs/sector_impact_mapping.yaml` 为唯一判定基准。  
2. 若镜像文件与主定义真源不一致，以主定义真源为准，并视为配置一致性缺陷。  
3. 成员 B 负责主定义真源；成员 C 只能消费该真源，不得另行派生第二套 sector 判定口径。  

### B-2 三段契约落地
- `semantic_event_type`
- `sector_candidates`
- `ticker_candidates`

### B-3 ticker_pool 白名单
- broad sector / sub-sector 双层一致性校验

### B-4 theme_tags / A0 Narrative Boost
- 只能辅助加分，不得单独触发 EXECUTE

### B-5 A1 target_tracking
- 必须绑定目标标的 / 代理资产，不得泛市场高分

### B 交付完成标准
- [ ] `sectors[]` 非白名单 = 0
- [ ] ticker 错配率显著下降
- [ ] `theme_tags` 不再是幽灵字段
- [ ] A1 与真实目标资产绑定

---

## 5.4 成员 C 详细职责（修订）
### C-1 replay 主键与 join 完整性
- **C 负责实现 writer / join / validator**
- 强制落盘：
  - `event_trace_id`
  - `request_id`
  - `batch_id`
  - `event_hash`

### C-2 原始采样落盘
- `raw_news_ingest.jsonl`

### C-3 队列调度升级
- FIFO → 新鲜度优先
- 保留 `ingest_seq / process_seq`

### C-4 并发抓价 + 幂等
- adapter
- batch
- cache
- failover
- `idempotency_key`

### C-5 Quarantine Activity Monitor（新增）
- 监测隔离流活跃度
- 仅当以下条件同时满足时触发：
  1. `gate_enabled = true`
  2. `ingest_count_1h > 0`
  3. `rejected_events_count_1h = 0`
  4. `quarantine_replay_count_1h = 0`
- 触发报警：
  - `QUARANTINE_SILENT_ALERT`

### C 交付完成标准
- [ ] replay 主键完整率 = 100%
- [ ] orphan replay = 0
- [ ] 原始采样可回溯
- [ ] 优先级队列不破坏 ingest 真源顺序
- [ ] 重试不重复写 replay / 不重复执行
- [ ] 隔离流活跃度监测已上线

---

# 六、测试门禁（修订闭合版）

## 6.1 阶段 0-3 必过 6 项硬测试
1. `hit_classifier_precision_test`
2. `contract_consistency_test`
3. `fallback_leak_test`
4. `sector_ticker_alignment_test`
5. `opportunity_required_for_execute_test`
6. `replay_join_integrity_test`

## 6.2 阶段 4 必过 3 项附加门禁测试
7. `dual_write_backward_compat_test`
8. `priority_queue_order_semantics_test`
9. `idempotent_replay_write_test`

## 6.3 上线前附加门禁
10. `provider_failover_recovery_test`
11. `quarantine_activity_monitor_test`
12. `rollback_sanitization_test`
13. `shadow_code_purge_gate`

---

# 七、DoR / DoD（修订数字阈值版）

## 7.1 Definition of Ready（DoR）
以下全部满足，才允许正式编码：

- [ ] v1.2 主稿已冻结
- [ ] 本正式冻结版已冻结
- [ ] 基线 + 压测基线已冻结
- [ ] 黄金样本已准备
- [ ] 分工边界已明确
- [ ] Joint Review 触点已公布
- [ ] flags 已建立
- [ ] rollback + sanitization 已建立
- [ ] quarantine 流准备完毕
- [ ] schema/config 真源已锁定

---

## 7.2 Definition of Done（DoD）
以下全部满足，才允许宣布“本轮修复完成”：

### 主链路正确性
- [ ] `missing_opportunity_but_execute_count = 0`
- [ ] `market_data_default_used_in_execute_count = 0`
- [ ] `sectors_non_whitelist_rate = 0`
- [ ] `placeholder_leak_rate <= 1%`
- [ ] `financial_rate < 35%`

### 审计与回放
- [ ] `replay_primary_key_completeness = 100%`
- [ ] `trace_join_success_rate >= 99.0%`
- [ ] `orphan_replay = 0`

### 兼容与顺序语义
- [ ] dual-write 兼容通过
- [ ] 优先级队列不破坏 ingest 真源顺序
- [ ] 重试不重复执行、不重复写 replay

### 性能
- [ ] `p95_decision_latency` 不得高于基线；阶段 4 目标为较基线下降 30%+
- [ ] `same_trace_ai_duplicate_call_rate` 较基线下降 50%+

### 回滚与清理
- [ ] 灰度期间未触发 blocker 级回滚
- [ ] rollback sanitization 脚本验证通过
- [ ] Shadow Code Purge Gate 通过（清除生产代码中的临时 print / 调试输出 / bypass）

---

# 八、最终一句话执行口令（发群版）

**先冻结基线（含压测基线）和真源，再上兼容层和唯一 Gate；先补最小证据日志，再切 A1 假验证和执行红线；再修 replay/join、sector/ticker、金融伪兜底；再做 provider/perf；最后补完整日志、评分、看板。凡涉及三方触点，必须 Joint Review；凡涉及回滚，必须带 sanitization 脚本；未满足数字化 DoD，不得宣称完成。**
